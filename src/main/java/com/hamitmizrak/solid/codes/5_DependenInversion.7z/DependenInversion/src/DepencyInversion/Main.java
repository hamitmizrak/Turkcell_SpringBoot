package DepencyInversion;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Message message = new Email();
        Notification notification = new Notification(message);
        notification.sender();
    }
}
