package DepencyInversion;

public interface Message {
    void sendMessage();
}
