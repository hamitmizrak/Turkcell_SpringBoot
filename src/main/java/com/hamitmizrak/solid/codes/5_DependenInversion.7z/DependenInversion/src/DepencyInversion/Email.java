package DepencyInversion;

public class Email implements Message {
    @Override
    public void sendMessage() {
        System.out.println("Email");
    }
}
