package DepencyInversion;

import java.util.List;

public class Notification {
    private Message message;

    public Notification(Message message) {
        this.message = message;
    }

    public void sender() {
        message.sendMessage();
    }

}
