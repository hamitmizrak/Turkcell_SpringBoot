package DepencyInversion;

public class Sms implements Message {
    @Override
    public void sendMessage() {
        System.out.println("Sms");
    }
}
