package NotDependencyInversion;

public class Email {

    public void sendEmail() {
        System.out.println("Email");
    }
}
