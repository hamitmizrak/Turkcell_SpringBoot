package NotDependencyInversion;

public class Sms {
    public void sendSms() {
        System.out.println("Sms");
    }
}
